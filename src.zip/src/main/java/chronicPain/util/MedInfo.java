package chronicPain.util;

/**
 * This class contain the details of the treatment.
 */
public class MedInfo {

    public static int MEDICINE_NAME = 0;
    public static int BASE_DOSAGE = 1;
    public static int UNIT = 2;
    public static int AMOUNT = 3;
    public static int TABS_OR_UNITS = 4;

}